import json
import os
import subprocess
from Inspector import *
from storage.pyStorage import pyStorage
import time


def lambda_handler(event, context):
    start_all = int(round(time.time() * 1000))

    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])

    # get the merged file
    sam_merged_file = event["samMerged"]

    bucket = event['output_buckets'][6]
    
    result_dict = {}

    # Load sam file
    start = int(round(time.time() * 1000))
    pyStorage.copy(sam_merged_file, '/tmp/merged.sam')
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta"] = (end - start)
    result_dict["dl_ALL"] = (end - start)

    # samtools sort
    result = subprocess.check_output('./samtools sort -O sam -T sample.sort -o /tmp/sorted.sam /tmp/merged.sam',
                                     shell=True).decode('ASCII')
    print(result)
    result = subprocess.check_output('./samtools view -b -S /tmp/sorted.sam -o /tmp/sorted.bam', shell=True).decode(
        'ASCII')
    print(result)
    result = subprocess.check_output(
        './samtools index /tmp/sorted.bam', shell=True).decode('ASCII')
    print(result)

    target_sorted_bam_file = bucket + 'sorted.bam'
    target_sorted_bam_bai_file = bucket + 'sorted.bam.bai'

    start_all_ups = int(round(time.time() * 1000))

    # Store output files
    start = int(round(time.time() * 1000))
    pyStorage.copy('/tmp/sorted.bam', target_sorted_bam_file)
    end = int(round(time.time() * 1000))
    result_dict["up_sorted.bam"] = (end - start)
    
    start = int(round(time.time() * 1000))
    pyStorage.copy('/tmp/sorted.bam.bai', target_sorted_bam_bai_file)
    end = int(round(time.time() * 1000))
    result_dict["up_sorted.bam.bai"] = (end - start)

    end_all_ups = int(round(time.time() * 1000))
    result_dict["up_ALL"] = (end_all_ups - start_all_ups)

    result_dict["bam"] = target_sorted_bam_file
    result_dict["bambai"] = target_sorted_bam_bai_file

    end_all = int(round(time.time() * 1000))
    result_dict["work_ALL"] = (end_all - start_all) - result_dict["dl_ALL"] - result_dict["up_ALL"]

    return result_dict
