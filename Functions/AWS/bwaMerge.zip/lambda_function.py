import json
import subprocess
import os
from Inspector import *
from storage.pyStorage import pyStorage
import time


def lambda_handler(event, context):
    start_all = int(round(time.time() * 1000))
    
    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])

    sam_collection = []
        
    # Parse if input from cfcl
    if type(event["sam"]) is dict:
        for x in event["sam"].keys():
            sam_collection.extend(event["sam"][x])
    else:
        sam_collection = event["sam"]
        
    print("Received sam files: {}".format(sam_collection))

    if len(sam_collection) == 1:
        return {
        "samMerged": sam_collection[0]
        } 
        

    bucket = event['output_buckets'][5]
    
    result_dict = {}
    
    start_all_dls = int(round(time.time() * 1000))
            
    # Load other files and merge them
    for i, file in enumerate(sam_collection,  start=1):
        start = int(round(time.time() * 1000))
        pyStorage.copy(file,  '/tmp/chunk'+str(i)+'.sam')
        end = int(round(time.time() * 1000))
        dict_key = "dl_chunk" + str(i) + ".sam"
        result_dict[dict_key] = (end - start)
        
    end_all_dls = int(round(time.time() * 1000))
    result_dict["dl_ALL"] = (end_all_dls - start_all_dls)

    # samtools merge finalBamFile.bam *.bam
    result = subprocess.check_output('./samtools merge -f /tmp/merged.sam /tmp/chunk*.sam', shell=True).decode('ASCII')
    print(result)       
    
    # Make new file merge file
    result = subprocess.check_output('ls /tmp/', shell=True).decode('ASCII')
    print(result)   
    
    result = subprocess.check_output('./samtools view -b -F 4 /tmp/merged.sam > /tmp/merged_slim.sam', shell=True).decode('ASCII')
        
    # Store new file
    start = int(round(time.time() * 1000))
    pyStorage.copy('/tmp/merged_slim.sam', bucket + 'merged.sam')
    end = int(round(time.time() * 1000))
    result_dict["up_merged.sam"] = (end - start)
    result_dict["up_ALL"] = (end - start)
    
    result_dict["samMerged"] = bucket + "merged.sam"
    result_dict["aws_access_key_id"] = event["aws_access_key_id"]
    result_dict["aws_secret_key"] = event["aws_secret_key"]
    result_dict["aws_session_token"] = event["aws_session_token"]
    result_dict["gcp_client_email"] = event["gcp_client_email"]
    result_dict["gcp_private_key"] = event["gcp_private_key"]
    result_dict["gcp_project_id"] = event["gcp_project_id"]
    result_dict["output_buckets"] = event["output_buckets"]

    end_all = int(round(time.time() * 1000))
    result_dict["work_ALL"] = (end_all - start_all) - result_dict["dl_ALL"] - result_dict["up_ALL"]

    return result_dict
