import json
import subprocess
import storage_handler
import os
from Inspector import *
from storage.pyStorage import pyStorage
import time


def lambda_handler(event, context):
    start_all = int(round(time.time() * 1000))

    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])

    aln_input = event["aln"]
    par_aln_name = [x for x in aln_input.keys() if "parALN" in x][0].split("/")[0]
    print(par_aln_name)
    bwa_r1_name = [x for x in aln_input.keys() if "bwaAlnR1" in x][0].split("/")[0]
    bwa_r2_name = [x for x in aln_input.keys() if "bwaAlnR2" in x][0].split("/")[0]

    chunk = aln_input[par_aln_name + "/fastaIndexed"]
    chunk_folder = event["chunk_folder"]
    
    # the produced alignments from bwaAln
    bwaAln1 = aln_input[bwa_r1_name + "/aln1"]
    bwaAln2 = aln_input[bwa_r2_name + "/aln2"]
    
    # the reads from the machines
    bwaAlnR1 = aln_input[par_aln_name + "/R1"]
    bwaAlnR2 = aln_input[par_aln_name + "/R2"]

#    bucket = os.environ.get('BUCKET')
    bucket = event["output_buckets"][4]
    
    result_dict = {}
    
    start_all_dls = int(round(time.time() * 1000))
    
    # Load chunk
    #storage_handler.load_file(bucket, chunk, '/tmp/chunk.fasta')
    start = int(round(time.time() * 1000))
    pyStorage.copy(chunk, '/tmp/chunk.fasta')
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta"] = (end - start)

    # Load R1 and R2
    #storage_handler.load_file(bucket, bwaAlnR1, '/tmp/R1.fq')
    #storage_handler.load_file(bucket, bwaAlnR2, '/tmp/R2.fq')
    start = int(round(time.time() * 1000))
    pyStorage.copy(bwaAlnR1, '/tmp/R1.fq')
    end = int(round(time.time() * 1000))
    result_dict["dl_R1.fq"] = (end - start)
    
    start = int(round(time.time() * 1000))
    pyStorage.copy(bwaAlnR2, '/tmp/R2.fq')
    end = int(round(time.time() * 1000))
    result_dict["dl_R2.fq"] = (end - start)

    # Load .sai files
    start = int(round(time.time() * 1000))
    pyStorage.copy(bwaAln1, '/tmp/R1.sai')
    end = int(round(time.time() * 1000))
    result_dict["dl_R1.sai"] = (end - start)
    
    start = int(round(time.time() * 1000))
    pyStorage.copy(bwaAln2, '/tmp/R2.sai')
    end = int(round(time.time() * 1000))
    result_dict["dl_R2.sai"] = (end - start)


    # Load index files (TODO check if these files are needed?)
    start = int(round(time.time() * 1000))
    result = pyStorage.copy(chunk_folder + 'chunk.fasta.amb', '/tmp/chunk.fasta.amb') 
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta.amb"] = (end - start)
    start = int(round(time.time() * 1000))
    result = pyStorage.copy(chunk_folder + 'chunk.fasta.ann', '/tmp/chunk.fasta.ann')
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta.ann"] = (end - start)
    start = int(round(time.time() * 1000))
    result = pyStorage.copy(chunk_folder + 'chunk.fasta.bwt', '/tmp/chunk.fasta.bwt')
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta.bwt"] = (end - start)
    start = int(round(time.time() * 1000))
    result = pyStorage.copy(chunk_folder + 'chunk.fasta.pac', '/tmp/chunk.fasta.pac')
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta.pac"] = (end - start)
    start = int(round(time.time() * 1000))
    result = pyStorage.copy(chunk_folder + 'chunk.fasta.sa', '/tmp/chunk.fasta.sa')
    end = int(round(time.time() * 1000))
    result_dict["dl_chunk.fasta.sa"] = (end - start)

    end_all_dls = int(round(time.time() * 1000))
    result_dict["dl_ALL"] = (end_all_dls - start_all_dls)

    # Index chunk
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)

    result = subprocess.check_output(
        './bwa sampe /tmp/chunk.fasta /tmp/R1.sai /tmp/R2.sai /tmp/R1.fq /tmp/R2.fq -f /tmp/chunk.sam',
        shell=True).decode('ASCII')
    print(result)
    
    # Delete old merge file
    result = subprocess.check_output('./samtools view -b -F 4 /tmp/chunk.sam > /tmp/slim_chunk.sam', shell=True).decode('ASCII')
    print(result)
    
    # Make new file merge file
    result = subprocess.check_output('ls /tmp/', shell=True).decode('ASCII')
    print(result)

    # Store new file
    start = int(round(time.time() * 1000))
    pyStorage.copy('/tmp/slim_chunk.sam', chunk_folder + 'chunk.sam')
    end = int(round(time.time() * 1000))
    result_dict["up_chunk.sam"] = (end - start)
    result_dict["up_ALL"] = (end - start)

    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)
    
    result_dict["sam"] = chunk_folder + "chunk.sam"
    result_dict["aws_access_key_id"] = event["aws_access_key_id"]
    result_dict["aws_secret_key"] = event["aws_secret_key"]
    result_dict["aws_session_token"] = event["aws_session_token"]
    result_dict["gcp_client_email"] = event["gcp_client_email"]
    result_dict["gcp_private_key"] = event["gcp_private_key"]
    result_dict["gcp_project_id"] = event["gcp_project_id"]
    result_dict["output_buckets"] = event["output_buckets"]

    end_all = int(round(time.time() * 1000))
    result_dict["work_ALL"] = (end_all - start_all) - result_dict["dl_ALL"] - result_dict["up_ALL"]

    return result_dict
