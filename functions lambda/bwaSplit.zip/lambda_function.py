import json
import os
import subprocess
from multiprocessing import Process, Pipe
from Inspector import *
from storage.pyStorage import pyStorage
import re


def create_chunk(file, written_file, start_line, end_line, input_file_lines, i, inspector, conn):
    # Import the module and collect data
    
    print('Creating chunk {}: start: {} end: {}'.format(i, start_line, end_line))

    # Replace all lines with null character except first line and chunk's range
    os.system('sed \'1! {' + str(start_line) + ',' + str(
    end_line) + '! s/./N/g }\' /tmp/' + file + ' > /tmp/chunks/chunk' + str(i) + '.fasta')

    # Check if chunk has same size as original file (not needed? sed is perfect)
    result = subprocess.check_output('wc -l /tmp/chunks/chunk' + str(i) + '.fasta',
		                         shell=True)
    chunk_lines = int(result.split(b' ')[0])
    if chunk_lines != input_file_lines:
        raise Exception('Splitting error!')

    # Store chunk in S3
    #storage_handler.store_file(bucket, written_file, '/tmp/chunks/chunk' + str(i) + '.fasta')
    inspector.addTimeStamp("Time Stamp before Upload:" + written_file)
    pyStorage.copy("/tmp/chunks/chunk" + str(i) + ".fasta", written_file)
    inspector.addTimeStamp("Time Stamp after Upload:" + written_file)
    
    print("Successfully written chunk file: {}.".format(written_file))
    conn.send(inspector)
    conn.close()
    
def lambda_handler(event, context):
    
    
    inspector = Inspector()
    inspector.inspectAll()
    
    inspector.addTimeStamp("Time Stamp at start")
    
    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])



    print("Running split with fasta: {}. Folders (optional): {}".format(
        event["fasta"],
        event["folders"] if "folders" in event.keys() else "Not specified"))

    number_chunks = int(event["chunks"])
    folderindex = int(event["folderindex"]) 
    
    bucket = event["output_buckets"][0]

    fastaFolder = bucket + event["fastaFolder"]
    folders =  fastaFolder + "/" + event["folders"]

#    if not (len(folders) == number_chunks):
#         raise ValueError("Specified number of folders doesn't match the specified chunks.")

    print("Using folders: {}".format(folders))

    file = event["fasta"]
    file_to_store = pyStorage.retrieve_file_name(file)
#    bucket = os.environ.get('BUCKET')
    

    os.system('mkdir /tmp/chunks')

    # Load input
    inspector.addTimeStamp("Time Stamp before Download:" + file)
    pyStorage.copy(file, "/tmp/" + file_to_store)
    inspector.addTimeStamp("Time Stamp after Download:"  + file)
    # Get line count of input file
    result = subprocess.check_output('wc -l /tmp/' + file_to_store, shell=True)
    input_file_lines = int(result.split(b' ')[0])

    # Get char count of input file
    result = subprocess.check_output('wc --chars /tmp/' + file_to_store, shell=True)
    input_file_characters = int(result.split(b' ')[0])

    print('Input has {} lines and {} characters'.format(input_file_lines, input_file_characters))

    # Calculate lines of chunks with start/end line per chunk
    # First line is the same for every chunk only other lines are replaced
    lines_per_chunk = (input_file_lines - 1) // number_chunks
    line_modulo = (input_file_lines - 1) % number_chunks

    if lines_per_chunk < 1:
        raise Exception("To many chunks!")

    print('Each chunk has {} lines and first {} chunks have one more'.format(lines_per_chunk, line_modulo))

    start_line = 2 + (folderindex - 1) * lines_per_chunk
    written_files = list()

    jobs = []
#    for i in range(number_chunks):
    i = 0
    end_line = start_line + lines_per_chunk - 1
    if i < line_modulo:
        end_line += 1
        
    written_file = folders + '/chunk.fasta'
        
    written_files.append(written_file)
    parent_conn, child_conn = Pipe()
    p = Process(target=create_chunk, args=(file_to_store, written_file, start_line, end_line, input_file_lines, i, inspector, child_conn), name='create_chunk')
    
    jobs.append(p)
    
    p.start()
    inspector = parent_conn.recv()
    start_line = end_line + 1

    for job in jobs:
        job.join()
            
    result = subprocess.check_output('ls -a /tmp/chunks/', shell=True).decode('ASCII')

    print("Written files: {}".format(written_files))
    
    inspector.addTimeStamp("Time Stamp at end")
    
    inspector.addAttribute("fasta", written_files)
    inspector.addAttribute("fastaFile", fastaFolder)
    inspector.addAttribute("output_buckets", event['output_buckets'])
    inspector.addAttribute("aws_access_key_id", event['aws_access_key_id'])
    inspector.addAttribute("aws_secret_key", event['aws_secret_key'])
    inspector.addAttribute("aws_session_token", event['aws_session_token'])
    inspector.addAttribute("gcp_client_email", event['gcp_client_email'])
    inspector.addAttribute("gcp_private_key", event['gcp_private_key'])
    inspector.addAttribute("gcp_project_id", event['gcp_project_id'])

    inspector.inspectAllDeltas()
    return inspector.finish()
