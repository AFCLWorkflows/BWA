import json
import os
import subprocess
from Inspector import *
from storage.pyStorage import pyStorage


def lambda_handler(event, context):
    # Import the module and collect data
    inspector = Inspector()
    inspector.inspectAll()
    
    inspector.addTimeStamp("Time Stamp at start")

    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])


    chunk_file = event["fastaIndexed"]
    download_chunk_folder = event["chunk_folder"]
    chunk_folder = pyStorage.retrieve_file_name(download_chunk_folder)
    r_file =  event['R1']
#    bucket = os.environ.get('BUCKET')
    bucket = event['output_buckets'][2]
    
    # Load chunk
    #result = storage_handler.load_file(bucket, chunk_file, '/tmp/chunk.fasta')
    inspector.addTimeStamp("Time Stamp before Download:" + chunk_file)
    result = pyStorage.copy(chunk_file, '/tmp/chunk.fasta')
    inspector.addTimeStamp("Time Stamp after Download:" + chunk_file)

    # Load R1 or R2
    #result = storage_handler.load_file(bucket, r_file, '/tmp/R1.fq')
    inspector.addTimeStamp("Time Stamp before Download:" + r_file)
    result = pyStorage.copy(r_file, '/tmp/R1.fq')
    inspector.addTimeStamp("Time Stamp after Download:" + r_file)

    files_to_download = [
        "chunk.fasta.amb",
        "chunk.fasta.ann",
        "chunk.fasta.bwt",
        "chunk.fasta.pac",
        "chunk.fasta.sa"
    ]

    # Load index files
    for file in files_to_download:
        #storage_handler.load_file(bucket, chunk_folder + file, '/tmp/' + file)
        inspector.addTimeStamp("Time Stamp before Download:" + download_chunk_folder + file)
        pyStorage.copy(download_chunk_folder + file, '/tmp/' + file)
        inspector.addTimeStamp("Time Stamp after Download:" + download_chunk_folder + file)
        
    # Index chunk
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print("Showing content after file load", result)

    print('./bwa aln /tmp/chunk.fasta /tmp/R1.fq -f /tmp/aln_saiR1.sai')
    result = subprocess.check_output(
        './bwa aln /tmp/chunk.fasta /tmp/R1.fq -f /tmp/aln_saR1.sai', shell=True).decode(
        'ASCII')
    print(result)

    alignment_file = bucket + chunk_folder + 'aln_saR1.sai'
    # Store new file
    #storage_handler.store_file(bucket, alignment_file, '/tmp/aln_saR1.sai')
    inspector.addTimeStamp("Time Stamp before Upload:" + alignment_file)
    pyStorage.copy('/tmp/aln_saR1.sai', alignment_file)
    inspector.addTimeStamp("Time Stamp after Upload:" + alignment_file)
        

    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)
    inspector.addTimeStamp("Time Stamp at end")

    inspector.addAttribute("aln1", alignment_file)
    inspector.addAttribute("output_buckets", event['output_buckets'])
    inspector.addAttribute("aws_access_key_id", event['aws_access_key_id'])
    inspector.addAttribute("aws_secret_key", event['aws_secret_key'])
    inspector.addAttribute("aws_session_token", event['aws_session_token'])
    inspector.addAttribute("gcp_client_email", event['gcp_client_email'])
    inspector.addAttribute("gcp_private_key", event['gcp_private_key'])
    inspector.addAttribute("gcp_project_id", event['gcp_project_id'])
    inspector.addAttribute("chunk_folder", event["chunk_folder"])

    inspector.inspectAllDeltas()
    return inspector.finish()


