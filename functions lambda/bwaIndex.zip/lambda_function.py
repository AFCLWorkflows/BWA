import json
import os
import subprocess
import storage_handler
from Inspector import *
from storage.pyStorage import pyStorage


def lambda_handler(event, context):
    # Import the module and collect data
    inspector = Inspector()
    inspector.inspectAll()
    inspector.addTimeStamp("Time Stamp at start")

    pyStorage.create_cred_file(aws_access_key_id=event['aws_access_key_id'], aws_secret_key=event['aws_secret_key'], aws_session_token=event['aws_session_token'],
                               gcp_client_email=event['gcp_client_email'], gcp_private_key=event['gcp_private_key'], gcp_project_id=event['gcp_project_id'])


    fast_file = event["fasta"]
    tmp_folder = pyStorage.retrieve_file_name(event["fasta"])
    chunk_folder = "/".join(tmp_folder.split("/")[:-1]) + "/"
    print("Using fast_file: {}".format(fast_file))
    
    bucket = event["output_buckets"][1]
    

    # Load chunk
    inspector.addTimeStamp("Time Stamp before Download:" + fast_file)
    result = pyStorage.copy(fast_file, '/tmp/chunk.fasta')
    inspector.addTimeStamp("Time Stamp after Download:" + fast_file)

    # Index chunk
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)

    result = subprocess.check_output('./bwa index /tmp/chunk.fasta', shell=True).decode('ASCII')
    print(result)

    files_to_store = [
        "chunk.fasta.amb",
        "chunk.fasta.ann",
        "chunk.fasta.bwt",
        "chunk.fasta.pac",
        "chunk.fasta.sa"
    ]

    for file in files_to_store:
        # Store new files
        tmp_file = '/tmp/' + file
        target_file = bucket + chunk_folder + file
        print("Writing tmp file: {} to s3: {}".format(tmp_file, target_file))
        inspector.addTimeStamp("Time Stamp before Upload: " + target_file)
        pyStorage.copy(tmp_file,  target_file)
        inspector.addTimeStamp("Time Stamp after Upload: " + target_file)
        #result = storage_handler.store_file(bucket, target_file, tmp_file)
        

    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    
    inspector.addTimeStamp("Time Stamp at end")

    inspector.addAttribute("fastaIndexed", fast_file)
    inspector.addAttribute("output_buckets", event['output_buckets'])
    inspector.addAttribute("aws_access_key_id", event['aws_access_key_id'])
    inspector.addAttribute("aws_secret_key", event['aws_secret_key'])
    inspector.addAttribute("aws_session_token", event['aws_session_token'])
    inspector.addAttribute("gcp_client_email", event['gcp_client_email'])
    inspector.addAttribute("gcp_private_key", event['gcp_private_key'])
    inspector.addAttribute("gcp_project_id", event['gcp_project_id'])
    inspector.addAttribute("chunk_folder", bucket + chunk_folder)

    inspector.inspectAllDeltas()
    return inspector.finish()
