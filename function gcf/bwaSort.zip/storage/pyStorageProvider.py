from enum import Enum

class pyStorageProvider(Enum):
    AWS = "AWS"
    GCP = "GCP"
