import subprocess
from Inspector import *
from storage.pyStorage import pyStorage


def main(request):
    # Import the module and collect data
    inspector = Inspector()
    inspector.inspectAll()

    inspector.addTimeStamp("Time Stamp at start")

    request_json = request.get_json()

    pyStorage.create_cred_file(aws_access_key_id=request_json['aws_access_key_id'], aws_secret_key=request_json['aws_secret_key'], aws_session_token=request_json['aws_session_token'],
                               gcp_client_email=request_json['gcp_client_email'], gcp_private_key=request_json['gcp_private_key'], gcp_project_id=request_json['gcp_project_id'])

    # get the merged file
    sam_merged_file = request_json["samMerged"]

    bucket = request_json['output_buckets'][6]

    # Load sam file
    inspector.addTimeStamp("Time Stamp before Download: " + sam_merged_file)
    pyStorage.copy(sam_merged_file, '/tmp/merged.sam')
    inspector.addTimeStamp("Time Stamp after Download: " + sam_merged_file)

    # samtools sort
    result = subprocess.check_output('./samtools sort -O sam -T sample.sort -o /tmp/sorted.sam /tmp/merged.sam',
                                     shell=True).decode('ASCII')
    print(result)
    result = subprocess.check_output('./samtools view -b -S /tmp/sorted.sam -o /tmp/sorted.bam', shell=True).decode(
        'ASCII')
    print(result)
    result = subprocess.check_output(
        './samtools index /tmp/sorted.bam', shell=True).decode('ASCII')
    print(result)

    target_sorted_bam_file = bucket + 'sorted.bam'
    target_sorted_bam_bai_file = bucket + 'sorted.bam.bai'

    # Store output files
    inspector.addTimeStamp(
        "Time Stamp before Upload:" + target_sorted_bam_file)
    pyStorage.copy('/tmp/sorted.bam', target_sorted_bam_file)
    inspector.addTimeStamp("Time Stamp after Upload:" + target_sorted_bam_file)
    inspector.addTimeStamp("Time Stamp before Upload:" +
                           target_sorted_bam_bai_file)
    pyStorage.copy('/tmp/sorted.bam.bai', target_sorted_bam_bai_file)
    inspector.addTimeStamp("Time Stamp after Upload:" +
                           target_sorted_bam_bai_file)

    inspector.addTimeStamp("Time Stamp at end")

    inspector.addAttribute("bam", target_sorted_bam_file)
    inspector.addAttribute("bambai", target_sorted_bam_bai_file)

    inspector.inspectAllDeltas()
    return inspector.finish()
