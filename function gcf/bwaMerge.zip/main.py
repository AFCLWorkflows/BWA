import subprocess
from Inspector import *
from storage.pyStorage import pyStorage


def main(request):
    # Import the module and collect data
    inspector = Inspector()
    inspector.inspectAll()
    
    inspector.addTimeStamp("Time Stamp at start")
    
    request_json = request.get_json()
    
    pyStorage.create_cred_file(aws_access_key_id=request_json['aws_access_key_id'], aws_secret_key=request_json['aws_secret_key'], aws_session_token=request_json['aws_session_token'],
                               gcp_client_email=request_json['gcp_client_email'], gcp_private_key=request_json['gcp_private_key'], gcp_project_id=request_json['gcp_project_id'])

    sam_collection = []

    # Parse if input from cfcl
    if type(request_json["sam"]) is dict:
        for x in request_json["sam"].keys():
            sam_collection.extend(request_json["sam"][x])
    else:
        sam_collection = request_json["sam"]

    print("Received sam files: {}".format(sam_collection))

    if len(sam_collection) == 1:
        return {
            "samMerged": sam_collection[0]
        }

    bucket = request_json['output_buckets'][0][5]

    # Load other files and merge them
    for i, file in enumerate(sam_collection,  start=1):
        #storage_handler.load_file(bucket, file, '/tmp/chunk'+str(i)+'.sam')
        inspector.addTimeStamp("Time Stamp before Download: " + file)
        pyStorage.copy(file,  '/tmp/chunk'+str(i)+'.sam')
        inspector.addTimeStamp("Time Stamp after Download: " + file)

    # samtools merge finalBamFile.bam *.bam
    result = subprocess.check_output(
        './samtools merge -f /tmp/merged.sam /tmp/chunk*.sam', shell=True).decode('ASCII')
    print(result)

    # Make new file merge file
    result = subprocess.check_output('ls /tmp/', shell=True).decode('ASCII')
    print(result)

    result = subprocess.check_output(
        './samtools view -b -F 4 /tmp/merged.sam > /tmp/merged_slim.sam', shell=True).decode('ASCII')

    # Store new file
    #storage_handler.store_file(bucket, 'merged.sam','/tmp/merged_slim.sam')
    inspector.addTimeStamp("Time Stamp before Upload: merged.sam")
    pyStorage.copy('/tmp/merged_slim.sam', bucket + 'merged.sam')
    inspector.addTimeStamp("Time Stamp after Upload: merged.sam")

    inspector.addTimeStamp("Time Stamp at end")

    inspector.addAttribute("samMerged", bucket + 'merged.sam')
    inspector.addAttribute("aws_access_key_id", request_json['aws_access_key_id'])
    inspector.addAttribute("aws_secret_key", request_json['aws_secret_key'])
    inspector.addAttribute("aws_session_token", request_json['aws_session_token'])
    inspector.addAttribute("gcp_client_email", request_json['gcp_client_email'])
    inspector.addAttribute("gcp_private_key", request_json['gcp_private_key'])
    inspector.addAttribute("gcp_project_id", request_json['gcp_project_id'])
    inspector.addAttribute("output_buckets", request_json["output_buckets"][0])

    inspector.inspectAllDeltas()
    return inspector.finish()
