import subprocess
import os
import json
from Inspector import *
from storage.pyStorage import pyStorage
from storage.pyUrlParser import pyUrlParser


def main(request):
    # Import the module and collect data
    inspector = Inspector()
    inspector.inspectAll()
    inspector.addAttribute("functionName", "bwa_index_fra")
    inspector.addTimeStamp("Time Stamp at start")
    request_json = request.get_json()
    
    pyStorage.create_cred_file(aws_access_key_id=request_json['aws_access_key_id'], aws_secret_key=request_json['aws_secret_key'], aws_session_token=request_json['aws_session_token'],
                               gcp_client_email=request_json['gcp_client_email'], gcp_private_key=request_json['gcp_private_key'], gcp_project_id=request_json['gcp_project_id'])


    fast_file = request_json["fasta"]
    tmp_folder = pyUrlParser.retrieve_file_name(request_json["fasta"])
    chunk_folder = "/".join(tmp_folder.split("/")[:-1]) + "/"
    print("Using fast_file: {}".format(fast_file))
    
    bucket = request_json["output_buckets"][1]
    

    # Load chunk
    inspector.addTimeStamp("Time Stamp before Download:" + fast_file)
    result = pyStorage.copy(fast_file, '/tmp/chunk.fasta')
    inspector.addTimeStamp("Time Stamp after Download:" + fast_file)

    # Index chunk
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)

    result = subprocess.check_output('./bwa index /tmp/chunk.fasta', shell=True).decode('ASCII')
    print(result)

    files_to_store = [
        "chunk.fasta.amb",
        "chunk.fasta.ann",
        "chunk.fasta.bwt",
        "chunk.fasta.pac",
        "chunk.fasta.sa"
    ]

    for file in files_to_store:
        # Store new files
        tmp_file = '/tmp/' + file
        target_file = bucket + chunk_folder + file
        print("Writing tmp file: {} to s3: {}".format(tmp_file, target_file))
        inspector.addTimeStamp("Time Stamp before Upload: " + target_file)
        pyStorage.copy(tmp_file,  target_file)
        inspector.addTimeStamp("Time Stamp after Upload: " + target_file)
        #result = storage_handler.store_file(bucket, target_file, tmp_file)
        

    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    
    inspector.addTimeStamp("Time Stamp at end")

    inspector.addAttribute("fastaIndexed", fast_file)
    inspector.addAttribute("output_buckets", request_json['output_buckets'])
    inspector.addAttribute("aws_access_key_id", request_json['aws_access_key_id'])
    inspector.addAttribute("aws_secret_key", request_json['aws_secret_key'])
    inspector.addAttribute("aws_session_token", request_json['aws_session_token'])
    inspector.addAttribute("gcp_client_email", request_json['gcp_client_email'])
    inspector.addAttribute("gcp_private_key", request_json['gcp_private_key'])
    inspector.addAttribute("gcp_project_id", request_json['gcp_project_id'])
    inspector.addAttribute("chunk_folder", bucket + chunk_folder)

    inspector.inspectAllDeltas()
    return inspector.finish()
