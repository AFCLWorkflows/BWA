import subprocess
from Inspector import *
from storage.pyStorage import pyStorage


def main(request):
    # Import the module and collect data
    inspector = Inspector()
    inspector.inspectAll()
    
    inspector.addTimeStamp("Time Stamp at start")
    
    request_json = request.get_json()
    
    pyStorage.create_cred_file(aws_access_key_id=request_json['aws_access_key_id'], aws_secret_key=request_json['aws_secret_key'], aws_session_token=request_json['aws_session_token'],
                               gcp_client_email=request_json['gcp_client_email'], gcp_private_key=request_json['gcp_private_key'], gcp_project_id=request_json['gcp_project_id'])

    aln_input = request_json["aln"]
    par_aln_name = [x for x in aln_input.keys(
    ) if "parALN" in x][0].split("/")[0]
    print(par_aln_name)
    bwa_r1_name = [x for x in aln_input.keys(
    ) if "bwaAlnR1" in x][0].split("/")[0]
    bwa_r2_name = [x for x in aln_input.keys(
    ) if "bwaAlnR2" in x][0].split("/")[0]

    chunk = aln_input[par_aln_name + "/fastaIndexed"]
    chunk_folder = request_json["chunk_folder"]

    # the produced alignments from bwaAln
    bwaAln1 = aln_input[bwa_r1_name + "/aln1"]
    bwaAln2 = aln_input[bwa_r2_name + "/aln2"]

    # the reads from the machines
    bwaAlnR1 = aln_input[par_aln_name + "/R1"]
    bwaAlnR2 = aln_input[par_aln_name + "/R2"]

#    bucket = os.environ.get('BUCKET')
    bucket = request_json["output_buckets"][4]

    inspector.addTimeStamp("beforeFilesystemUse")

    # Load chunk
    #storage_handler.load_file(bucket, chunk, '/tmp/chunk.fasta')
    inspector.addTimeStamp("Time Stamp before Download:" + chunk)
    pyStorage.copy(chunk, '/tmp/chunk.fasta')
    inspector.addTimeStamp("Time Stamp after Download:" + chunk)

    # Load R1 and R2
    #storage_handler.load_file(bucket, bwaAlnR1, '/tmp/R1.fq')
    #storage_handler.load_file(bucket, bwaAlnR2, '/tmp/R2.fq')
    inspector.addTimeStamp("Time Stamp before Download:" + bwaAlnR1)
    pyStorage.copy(bwaAlnR1, '/tmp/R1.fq')
    inspector.addTimeStamp("Time Stamp after Download:" + bwaAlnR1)
    inspector.addTimeStamp("Time Stamp before Download:" + bwaAlnR2)
    pyStorage.copy(bwaAlnR2, '/tmp/R2.fq')
    inspector.addTimeStamp("Time Stamp after Download:" + bwaAlnR2)

    # Load .sai files
    inspector.addTimeStamp("Time Stamp before Download:" + bwaAln1)
    pyStorage.copy(bwaAln1, '/tmp/R1.sai')
    inspector.addTimeStamp("Time Stamp after Download:" + bwaAln1)
    inspector.addTimeStamp("Time Stamp before Download:" + bwaAln2)
    pyStorage.copy(bwaAln2, '/tmp/R2.sai')
    inspector.addTimeStamp("Time Stamp after Download:" + bwaAln2)

    # Load index files (TODO check if these files are needed?)
    inspector.addTimeStamp("Time Stamp before Download:" +
                           chunk_folder + 'chunk.fasta.amb')
    result = pyStorage.copy(
        chunk_folder + 'chunk.fasta.amb', '/tmp/chunk.fasta.amb')
    inspector.addTimeStamp("Time Stamp after Download: " +
                           chunk_folder + 'chunk.fasta.amb')
    inspector.addTimeStamp("Time Stamp before Download:" +
                           chunk_folder + 'chunk.fasta.ann')
    result = pyStorage.copy(
        chunk_folder + 'chunk.fasta.ann', '/tmp/chunk.fasta.ann')
    inspector.addTimeStamp("Time Stamp after Download:" +
                           chunk_folder + 'chunk.fasta.an')
    inspector.addTimeStamp("Time Stamp before Download:" +
                           chunk_folder + 'chunk.fasta.bwt')
    result = pyStorage.copy(
        chunk_folder + 'chunk.fasta.bwt', '/tmp/chunk.fasta.bwt')
    inspector.addTimeStamp("Time Stamp after Download:" +
                           chunk_folder + 'chunk.fasta.bwt')
    inspector.addTimeStamp("Time Stamp before Download:" +
                           chunk_folder + 'chunk.fasta.pac')
    result = pyStorage.copy(
        chunk_folder + 'chunk.fasta.pac', '/tmp/chunk.fasta.pac')
    inspector.addTimeStamp("Time Stamp after Download:" +
                           chunk_folder + 'chunk.fasta.pac')
    inspector.addTimeStamp("Time Stamp before Download:" +
                           chunk_folder + 'chunk.fasta.sa')
    result = pyStorage.copy(
        chunk_folder + 'chunk.fasta.sa', '/tmp/chunk.fasta.sa')
    inspector.addTimeStamp("Time Stamp after Download:" +
                           chunk_folder + 'chunk.fasta.sa')

    # Index chunk
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)

    result = subprocess.check_output(
        './bwa sampe /tmp/chunk.fasta /tmp/R1.sai /tmp/R2.sai /tmp/R1.fq /tmp/R2.fq -f /tmp/chunk.sam',
        shell=True).decode('ASCII')
    print(result)

    # Delete old merge file
    result = subprocess.check_output(
        './samtools view -b -F 4 /tmp/chunk.sam > /tmp/slim_chunk.sam', shell=True).decode('ASCII')
    print(result)

    # Make new file merge file
    result = subprocess.check_output('ls /tmp/', shell=True).decode('ASCII')
    print(result)

    # Store new file
    #storage_handler.store_file(bucket, chunk_folder + 'chunk.sam', '/tmp/slim_chunk.sam')
    inspector.addTimeStamp("Time Stamp before Upload:" +
                           chunk_folder + 'chunk.sam')
    pyStorage.copy('/tmp/slim_chunk.sam', chunk_folder + 'chunk.sam')
    inspector.addTimeStamp("Time Stamp after Upload:" +
                           chunk_folder + 'chunk.sam')

    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)

    inspector.addTimeStamp("Time Stamp at end")

    inspector.addAttribute("sam", chunk_folder + 'chunk.sam')
    inspector.addAttribute("aws_access_key_id", request_json['aws_access_key_id'])
    inspector.addAttribute("aws_secret_key", request_json['aws_secret_key'])
    inspector.addAttribute("aws_session_token", request_json['aws_session_token'])
    inspector.addAttribute("gcp_client_email", request_json['gcp_client_email'])
    inspector.addAttribute("gcp_private_key", request_json['gcp_private_key'])
    inspector.addAttribute("gcp_project_id", request_json['gcp_project_id'])
    inspector.addAttribute("output_buckets", request_json["output_buckets"])

    inspector.inspectAllDeltas()
    return inspector.finish()
