import subprocess
import os
from Inspector import *
from storage.pyStorage import pyStorage
from storage.pyUrlParser import pyUrlParser

def main(request):
    # Import the module and collect data
    inspector = Inspector()
    inspector.inspectAll()
    inspector.addAttribute("functionName", "bwa_aln2_fra")
    inspector.addTimeStamp("Time Stamp at start")
    request_json = request.get_json()
    
    pyStorage.create_cred_file(aws_access_key_id=request_json['aws_access_key_id'], aws_secret_key=request_json['aws_secret_key'], aws_session_token=request_json['aws_session_token'],
                               gcp_client_email=request_json['gcp_client_email'], gcp_private_key=request_json['gcp_private_key'], gcp_project_id=request_json['gcp_project_id'])

    chunk_file = request_json["fastaIndexed"]
    download_chunk_folder = request_json["chunk_folder"]
    chunk_folder = pyUrlParser.retrieve_file_name(download_chunk_folder)
    r_file = request_json['R2']
#    bucket = os.environ.get('BUCKET')
    bucket = request_json["output_buckets"][3]

    # Load chunk
    #result = storage_handler.load_file(bucket, chunk_file, '/tmp/chunk.fasta')
    inspector.addTimeStamp("Time Stamp before Download:" + chunk_file)
    result = pyStorage.copy(chunk_file, '/tmp/chunk.fasta')
    inspector.addTimeStamp("Time Stamp after Download:" + chunk_file)

    # Load R1 or R2
    #result = storage_handler.load_file(bucket, r_file, '/tmp/R2.fq')
    inspector.addTimeStamp("Time Stamp before Download:" + r_file)
    result = pyStorage.copy(r_file, '/tmp/R2.fq')
    inspector.addTimeStamp("Time Stamp after Download:" + r_file)

    files_to_download = [
        "chunk.fasta.amb",
        "chunk.fasta.ann",
        "chunk.fasta.bwt",
        "chunk.fasta.pac",
        "chunk.fasta.sa"
    ]

    # Load index files
    for file in files_to_download:
        #storage_handler.load_file(bucket, chunk_folder + file, '/tmp/' + file)
        inspector.addTimeStamp(
            "Time Stamp before Download: " + download_chunk_folder + file)
        pyStorage.copy(download_chunk_folder + file, "/tmp/" + file)
        inspector.addTimeStamp(
            "Time Stamp after Download: " + download_chunk_folder + file)

    # Index chunk
    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print("Showing content after file load", result)

    print('./bwa aln /tmp/chunk.fasta /tmp/R2.fq -f /tmp/aln_saiR2.sai')
    result = subprocess.check_output(
        './bwa aln /tmp/chunk.fasta /tmp/R2.fq -f /tmp/aln_saR2.sai', shell=True).decode(
        'ASCII')
    print(result)

    alignment_file = bucket + chunk_folder + 'aln_saR2.sai'
    # Store new file
    #storage_handler.store_file(bucket, alignment_file, '/tmp/aln_saR2.sai')
    inspector.addTimeStamp("Time Stamp before Upload:" + alignment_file)
    pyStorage.copy('/tmp/aln_saR2.sai', alignment_file)
    inspector.addTimeStamp("Time Stamp after Upload:" + alignment_file)

    result = subprocess.check_output('ls -a /tmp/', shell=True).decode('ASCII')
    print(result)

    inspector.addTimeStamp("Time Stamp at end")

    inspector.addAttribute("aln2", alignment_file)
    inspector.addAttribute("output_buckets", request_json['output_buckets'])
    inspector.addAttribute("aws_access_key_id", request_json['aws_access_key_id'])
    inspector.addAttribute("aws_secret_key", request_json['aws_secret_key'])
    inspector.addAttribute("aws_session_token", request_json['aws_session_token'])
    inspector.addAttribute("gcp_client_email", request_json['gcp_client_email'])
    inspector.addAttribute("gcp_private_key", request_json['gcp_private_key'])
    inspector.addAttribute("gcp_project_id", request_json['gcp_project_id'])
    inspector.addAttribute("chunk_folder", request_json["chunk_folder"])

    inspector.inspectAllDeltas()
    return inspector.finish()
